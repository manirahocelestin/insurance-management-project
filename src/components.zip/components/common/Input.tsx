// import React from 'react';

// interface InputControlProps {
//   label: string;
//   error?: string;
//   register: {
//     onChange: React.ChangeEventHandler<HTMLInputElement>;
//     onBlur: React.FocusEventHandler<HTMLInputElement>;
//     ref: React.Ref<HTMLInputElement>;
//   };
//   placeholder?: string;
//   [key: string]: any; // Allows additional props
// }

// const Input: React.FC<InputControlProps> = ({
//   label,
//   error,
//   register,
//   placeholder,
// }) => {
//   return (
//     <div className="mb-4">
//       <label className="block text-gray-700">{label}</label>
//       <input
//         {...register} // Correctly spreading register props
//         placeholder={placeholder}
//         className="border p-2 rounded w-full"
//       />
//       {error && <p className="text-red-500">{error}</p>}
//     </div>
//   );
// };

// export default Input;
// src/components/Common/Input.tsx

import React from 'react';

interface InputProps {
  label: string;
  name: string;
  type?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  required?: boolean;
  placeholder?: string;
  
}

export const Input: React.FC<InputProps> = ({ label, name, type , value, onChange, error, required = false,placeholder }) => {
  return (
    <div className="mb-4">
      <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor={name}>
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        className={`shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ${error ? 'border-red-500' : ''}`}
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        required={required}
      />
      {error && <p className="text-red-500 text-xs italic">{error}</p>}
    </div>
  );
};
