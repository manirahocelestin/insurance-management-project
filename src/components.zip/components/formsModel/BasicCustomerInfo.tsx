import React from 'react';

export interface BasicCustomerInfo {
  customerType: string;
  customer_ID: string;
  salutation: string;
  national_ID_Type: string;
  national_ID_Number: string;
  customer_Name: string;
  surname: string;
  forename_1: string;
}


export const BasicInfoSection = () => {
  const [formData, setFormData] = React.useState<BasicCustomerInfo>({
    customerType: '',
    customer_ID: '',
    salutation: '',
    national_ID_Type: '',
    national_ID_Number: '',
    customer_Name: '',
    surname: '',
    forename_1: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
  //   e.preventDefault();
  //   // Add validation logic here
  // };

  return (
    <div className="bg-gray-100 p-6 rounded-lg shadow-md max-w-lg mx-auto">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Basic Customer Information</h2>
      <form  className="space-y-4">
        
      <div className="grid grid-cols-2 gap-4">
  <div>
    <label htmlFor="customerType" className="block text-sm font-medium text-gray-700">
      Customer Type
    </label>
    <input
      type="text"
      id="customerType"
      name="customerType"
      value={formData.customerType}
      onChange={handleChange}
      className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
      placeholder="Enter customer type"
      required
    />
  </div>

  <div>
    <label htmlFor="customer_ID" className="block text-sm font-medium text-gray-700">
      Customer ID
    </label>
    <input
      type="text"
      id="customer_ID"
      name="customer_ID"
      value={formData.customer_ID}
      onChange={handleChange}
      className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
      placeholder="Enter customer ID"
      required
    />
  </div>
</div>


        <div className="grid grid-cols-2 gap-4">
        
          <div>

          
        {/* Salutation */}

        
          <label htmlFor="salutation" className="block text-sm font-medium text-gray-700">
            Salutation
          </label>
          <select
            id="salutation"
            name="salutation"
            value={formData.salutation}
            onChange={handleChange}
            className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            required
          >
            <option value="">Select salutation</option>
            <option value="Mr">Mr</option>
            <option value="Ms">Ms</option>
            <option value="Mrs">Mrs</option>
            <option value="Miss">Miss</option>
            <option value="Dr">Dr</option>
          </select>

          </div>
          
          


          
            <div>
          {/*national_ID_Type */}


          <label htmlFor="national_ID_Type" className= "balock text-sm font-medium text -gray-700">
            National ID Type
            </label>
            
            <select
              id="national_ID_Type"
              name="national_ID_Type"
              value={formData.national_ID_Type}
              onChange={handleChange}
              className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
              >
                <option value="">Select National ID Type</option>
                <option value="Passport">Passport</option>
                <option value="ID Card">ID Card</option>
                <option value="Driver's License">Driver's License</option>
                <option value="Other">Other</option>
                </select>

                </div>

                
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
            

            <label htmlFor="national_ID_Number" className='block text-sm font-medium text-gray-700'>
              National-ID_Number
            </label>
            <input
            type ="text"
            id='national_ID_Number'
            name="national_ID_Number"
            value={formData.national_ID_Number}
            onChange={handleChange}
            className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            placeholder='Enter national ID number'
            required

            />
            </div>
            <div>
            
            <label htmlFor='customer_Name' className="block text-sm font-medium text-gray-700">
              Customer Name
            </label>
            <input
            type='text'
            id='customer_Name'
            name='customer_Name'
            value={formData.customer_Name}
            onChange={handleChange}
            className='mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500'
            placeholder='Enter customer name'
            required

            />
            </div>
            </div>
            <div className='grid grid-cols-2 gap-4'>
              <div>

            <label htmlFor='surname' className="block text-sm font-medium text-gray-700">
              SurName
              </label>
              <input
              type='text'
              id='surname'
              name='surname'
              value={formData.surname}
              onChange={handleChange}
              className='mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500'
              placeholder='Enter surname'
              required
              />
              </div>
              <div>

              <label htmlFor='forname_1' className='block text-sm font-medium text-gray-700'>
                forename_1
                </label>
                <input
                type='text'
                id='forname_1'
                name='forename_1'
                onChange={handleChange}
                value={formData.forename_1}
                
                className='mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500'
                placeholder='enter forename_1'
                required
                />
                </div>
              
        </div>

        
      </form>
    </div>
  );
};





// interface BasicInfoSectionProps {
//   data: BasicCustomerInfo;
//   onChange: (data: BasicCustomerInfo) => void;
//   errors?: Partial<Record<keyof BasicCustomerInfo, string>>;
// }

// export const BasicInfoSection: React.FC<BasicInfoSectionProps> = ({ data, onChange, errors = {} }) => {
//   const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
//     const { name, value } = e.target;
//     onChange({ ...data, [name]: value });
//   };

  // return (
  //   <div>
  //     <Input
  //       label='Customer Type'
  //       name='customerTypes'
  //       value={data.customerType}
  //       onChange={handleChange}
  //       error={errors.customerType}
  //       required
  //     />

      {/* <Input
        label="Customer ID"
        name='customer_ID'
        value={data.customer_ID}
        onChange={handleChange}
        error={errors.customer_ID}
        required
      />

      <Select
        label='Salutation'
        name='salutation'
        value={data.salutation}
        options={[
          { value: "Mr", label: "Mr" },
          { value: "Ms", label: "Ms" },
          { value: "Mrs", label: "Mrs" },
        ]}
        onChange={handleChange}
        error={errors.salutation}
        required
      />

      <Select
        label="National ID Type"
        name="national_ID_Type"
        value={data.national_ID_Type}
        options={[
          { value: 'NID', label: 'NID' },
          { value: 'PASSPORT', label: 'PASSPORT' }
        ]}
        onChange={handleChange}
        error={errors.national_ID_Type}
        required
      />

      <Input
        label="National ID Number"
        name='national_ID_Number'
        value={data.national_ID_Number}
        onChange={handleChange}
        error={errors.national_ID_Number}
        required
      />

      <Input
        label='Customer Name'
        name='customer_Name'
        value={data.customer_Name}
        type='text'
        onChange={handleChange}
        error={errors.customer_Name}
        required
      />

      <Input
        label='Surname'
        name='surname'
        value={data.surname}
        onChange={handleChange}
        error={errors.surname}
      />

      <Input
        label="Forename 1"
        name='forename_1'
        value={data.forename_1}
        onChange={handleChange}
        error={errors.forename_1}
      /> */}
//     </div>
//   );
// };

// import React, { useEffect } from 'react';
// import { Input } from '../common/Input';
// import { Select } from '../common/Select';

// interface BasicCustomerInfo {
//   customerType: string;
//   customer_ID: string;
//   salutation: string;
//   national_ID_Type: string;
//   national_ID_Number: string;
//   customer_Name: string;
//   surname: string;
//   forename_1: string;
// }

// interface BasicInfoSectionProps {
//   data: BasicCustomerInfo;
//   onChange: (data: BasicCustomerInfo) => void;
//   errors?: Partial<Record<keyof BasicCustomerInfo, string>>;
// }

// const defaultData: BasicCustomerInfo = {
//   customerType: 'NID',
//   customer_ID: '123456',
//   salutation: 'Mr',
//   national_ID_Type: 'NID',
//   national_ID_Number: '987654321',
//   customer_Name: 'John Doe',
//   surname: 'Doe',
//   forename_1: 'John',
// };

// export const BasicInfoSection: React.FC<BasicInfoSectionProps> = ({ data = defaultData, onChange, errors = {} }) => {
//   useEffect(() => {
//     onChange(defaultData);
//   }, []);

//   const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
//     const { name, value } = e.target;
//     onChange({ ...data, [name]: value });
//   };

//   return (
//     <div>
//       <Input
//         label='Customer Type'
//         name='customerType'
//         value={data.customerType}
//         onChange={handleChange}
//         error={errors.customerType}
//         required
//         type='text'
//       />

//       <Input
//         label="Customer ID"
//         name='customer_ID'
//         value={data.customer_ID}
//         onChange={handleChange}
//         error={errors.customer_ID}
//         required
//         type='text'
//       />

//       <Select
//         label='Salutation'
//         name='salutation'
//         value={data.salutation}
//         options={[
//           { value: "Mr", label: "Mr" },
//           { value: "Ms", label: "Ms" },
//           { value: "Mrs", label: "Mrs" },
//         ]}
//         onChange={handleChange}
//         error={errors.salutation}
//         required
//       />

//       <Select
//         label="National ID Type"
//         name="national_ID_Type"
//         value={data.national_ID_Type}
//         options={[
//           { value: 'NID', label: 'NID' },
//           { value: 'PASSPORT', label: 'PASSPORT' }
//         ]}
//         onChange={handleChange}
//         error={errors.national_ID_Type}
//         required
//       />

//       <Input
//         label="National ID Number"
//         name='national_ID_Number'
//         value={data.national_ID_Number}
//         onChange={handleChange}
//         error={errors.national_ID_Number}
//         required
//         type='text'
//       />

//       <Input
//         label='Customer Name'
//         name='customer_Name'
//         value={data.customer_Name}
//         type='text'
//         onChange={handleChange}
//         error={errors.customer_Name}
//         required
//       />

//       <Input
//         label='Surname'
//         name='surname'
//         value={data.surname}
//         onChange={handleChange}
//         error={errors.surname}
//         type='text'
//       />

//       <Input
//         label="Forename 1"
//         name='forename_1'
//         value={data.forename_1}
//         onChange={handleChange}
//         error={errors.forename_1}
//         type='text'
//       />
//     </div>
//   );
// };
